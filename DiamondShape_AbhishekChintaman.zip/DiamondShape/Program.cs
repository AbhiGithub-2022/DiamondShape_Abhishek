﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RnD_ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isValid = false;
            bool exitPrinting = false;
            char chrExit;
            char chrInput;

            do
            {
                do
                {
                    Console.WriteLine("Please enter a letter from A to Z to see a Diamond starting with 'A' to the supplied letter at the widest point.");
                    Console.Write("Input: ");
                    chrInput = Console.ReadKey().KeyChar;

                    Console.WriteLine();

                    isValid = PrintDiomond(char.ToUpper(chrInput));

                } while (!isValid);

                Console.Write("Do you want to Exit, enter Y or N ? ");
                chrExit = Console.ReadKey().KeyChar;
                Console.WriteLine();

                if (char.ToUpper(chrExit) == 'Y')
                {
                    exitPrinting = true;
                    Environment.Exit(0);
                }
            } while (!exitPrinting);

            Console.ReadLine();
        }

        public static bool PrintDiomond(char chrInput)
        {
            string strLetter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            int intTotalCharacters;
            int intTotalLines;
            int intIndex;
            bool isValid = false;

            //Identifying character index, total lines in upper half Diamond and characters in each line

            intIndex = strLetter.IndexOf(chrInput);

            if (intIndex >= 0)
            {
                intTotalCharacters = (intIndex + 1) + intIndex;
                intTotalLines = (intIndex + 1);
                isValid = true;
            }
            else
            {
                // Checking validation
                Console.WriteLine("Invalid input!!. Please provide a single letter from A to Z or a to z.");
                return isValid;
            }

            // Making upper half Diamond: Preparing list of blank spaces in each line and placing the total characters in each line

            List<string> lstInitial = new List<string>();

            int intStartIndex = 0;
            int intLastIndex = intTotalCharacters - 1;
            int intWorkingIndex = intIndex;

            for (int i = 0; i < intTotalLines; i++)
            {
                // Preparing the line with all the blank spaces

                string strResultLine = new string(' ', intTotalCharacters);

                // Placing the actual characters in each line to make Diamond Shape

                char[] chrTemp = strResultLine.ToCharArray();

                chrTemp[intStartIndex] = strLetter[intWorkingIndex];
                chrTemp[intLastIndex] = strLetter[intWorkingIndex];

                intStartIndex++;
                intLastIndex--;
                intWorkingIndex--;

                lstInitial.Add(new string(chrTemp));
            }

            // Create a final List of actual lines and actual characters in each lines

            List<string> lstFinal = new List<string>();

            lstFinal.AddRange(lstInitial);
            lstFinal.Sort();

            lstInitial.RemoveAt(0);
            lstFinal.AddRange(lstInitial);

            // Printing the Diamond Shape

            Console.WriteLine("Output Diamond: ");
            foreach (var item in lstFinal)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();

            return isValid;
        }
    }
}
